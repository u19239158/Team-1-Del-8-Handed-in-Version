export interface JwtRequest {
    username: string;
    password: string;
}
