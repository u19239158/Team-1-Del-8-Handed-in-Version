import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packing-report',
  templateUrl: './packing-report.component.html',
  styleUrls: ['./packing-report.component.scss']
})
export class PackingReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
