﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace NKAP_API_2.Models
{
    public class ProductCategoryModel
    {
        [JsonProperty("productcategoryid")]
        public int ProductCategoryID
        { get; set; }

        [JsonProperty("ProductCategoryDescription")]
        public string ProductCategoryDesc
        { get; set; }

        [JsonProperty("productcategoryimage")]
        public string ProductCategoryImage
        { get; set; }

        [JsonProperty("userusername")]
        public string UserUsername
        { get; set; }

        [JsonProperty("usersid")]
        public int UsersID
        { get; set; }
    }
}
