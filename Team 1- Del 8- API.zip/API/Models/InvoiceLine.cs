﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NKAP_API_2.Models
{
    public class InvoiceLine
    {
        public int id { get; set; }

        public int quantity { get; set; }

        public string name { get; set; }

    }
}
