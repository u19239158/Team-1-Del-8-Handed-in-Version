﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NKAP_API_2.Models
{
    public class FrontsideModel
    {
        public List<ProductItemModel> withspecial = new List<ProductItemModel>();
        public List<ProductItemModel> withoutspecial = new List<ProductItemModel>();
    }
}
