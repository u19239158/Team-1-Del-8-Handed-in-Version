﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace NKAP_API_2.RequestCourierDelivery
//{
//    public class CourierOrderMailService
//    {
//        //var response = CourierOrderMail.Execute(emailAddress);
//    }
//}
