﻿using System;
using System.Collections.Generic;

#nullable disable

namespace NKAP_API_2.EF
{
    public partial class MaxDelivery
    {
        public int MaxId { get; set; }
        public int? MaxNumber { get; set; }
    }
}
