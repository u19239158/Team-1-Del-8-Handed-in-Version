﻿using System;
using System.Collections.Generic;

#nullable disable

namespace NKAP_API_2.EF
{
    public partial class Markup
    {
        public int MarkupId { get; set; }
        public decimal? MarkupPercentage { get; set; }
    }
}
