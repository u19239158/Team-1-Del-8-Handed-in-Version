﻿using System;
using System.Collections.Generic;

#nullable disable

namespace NKAP_API_2.EF
{
    public partial class Vat
    {
        public int VatId { get; set; }
        public decimal? VatPercentage { get; set; }
    }
}
